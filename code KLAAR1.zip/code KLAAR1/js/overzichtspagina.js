var body = document.body
var zoekIcon = document.querySelector('header nav ul li:nth-of-type(1) img')

function openBalk () { body.classList.toggle('balk') }

zoekIcon.addEventListener('click', openBalk)





var plusButton = document.querySelector('main > section > article:nth-of-type(1) header img');
var article = document.querySelector('main > section > article:nth-of-type(1)');
var opgeslagen = document.querySelector('main > section > p');

var hideArticle = function() {
    article.classList.toggle('hideAnimation');
    opgeslagen.classList.toggle('hide');

}

plusButton.addEventListener('click', hideArticle);










































//var body = document.body
//var ZoekIconOpen= document.querySelector('nav ul label input')
//
//
//ZoekIconOpen.addEventListener('click', openFilter)
//
//function openFilter() { body.classList.toggle('zoek')
//}








//var body = document.body
//var ZoekIconOpen= document.querySelector('body > header nav ul label input')
//var ZoekIconClose= document.querySelector('body > header nav ul li:nth-of-type(1) img')
//
//
//ZoekIcon.addEventListener('click', openFilter)
//ZoekIcon.addEventListener('click', closeFilter)
//
//function openZoekIcon() { body.classList.add('balk')
//}
//
//function closeZoekIcon() { body.classList.remove('balk')
//}









//var body = document.body
//var btnFilterOpen = document.querySelector('header button')
//var btnFilterClose = document.querySelector('form button')
//
//btnFilterOpen.addEventListener('click', openFilter)
//btnFilterClose.addEventListener('click', closeFilter)
//
//function openFilter() {
//  body.classList.add('filter')
//}
//
//function closeFilter(e) {
//  e.preventDefault()
//  body.classList.remove('filter')
//}


var body = document.body
var heartIconLeeg = document.querySelector('header > img:nth-of-type(1)')
var heartIconVol = document.querySelector('header > img:nth-of-type(2)');
var popupIcon = document.querySelector('header img:nth-of-type(3)');

var heartFill = function() {
    heartIconLeeg.classList.toggle('hidden');
    heartIconVol.classList.toggle('hidden');
    popupIcon.classList.toggle('hidden');
    popupIcon.classList.toggle('popupAnimation')
}



heartIconLeeg.addEventListener('click', heartFill);

heartIconVol.addEventListener('click', heartFill);


